*************************************************************************
   ____  ____ 
  /   /\/   / 
 /___/  \  /   
 \   \   \/    � Copyright 2014�2020 Xilinx, Inc. All rights reserved.
  \   \        This file contains confidential and proprietary 
  /   /        information of Xilinx, Inc. and is protected under U.S. 
 /___/   /\    and international copyright and other intellectual 
 \   \  /  \   property laws. 
  \___\/\___\ 
 
*************************************************************************

Vendor: Xilinx 
Reference Design Version: 1.7
readme.txt Version: 1.7
Date Last Modified: 12/17/2020
Date Created: 05/19/2014
Associated Filename: xtp344-ultrascale-schematic-review-checklist.zip

Supported Device(s): UltraScale Architecture
Purpose: This ZIP file contains the schematic review checklist
Document Reference: XTP344
   
*************************************************************************

Disclaimer: 

      This disclaimer is not a license and does not grant any rights to 
      the materials distributed herewith. Except as otherwise provided in 
      a valid license issued to you by Xilinx, and to the maximum extent 
      permitted by applicable law: (1) THESE MATERIALS ARE MADE AVAILABLE 
      "AS IS" AND WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL 
      WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, 
      INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
      NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and 
      (2) Xilinx shall not be liable (whether in contract or tort, 
      including negligence, or under any other theory of liability) for 
      any loss or damage of any kind or nature related to, arising under 
      or in connection with these materials, including for any direct, or 
      any indirect, special, incidental, or consequential loss or damage 
      (including loss of data, profits, goodwill, or any type of loss or 
      damage suffered as a result of any action brought by a third party) 
      even if such damage or loss was reasonably foreseeable or Xilinx 
      had been advised of the possibility of the same.

Critical Applications:

      Xilinx products are not designed or intended to be fail-safe, or 
      for use in any application requiring fail-safe performance, such as 
      life-support or safety devices or systems, Class III medical 
      devices, nuclear facilities, applications related to the deployment 
      of airbags, or any other applications that could lead to death, 
      personal injury, or severe property or environmental damage 
      (individually and collectively, "Critical Applications"). Customer 
      assumes the sole risk and liability of any use of Xilinx products 
      in Critical Applications, subject only to applicable laws and 
      regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS 
FILE AT ALL TIMES.

*************************************************************************

This readme file contains the following sections:

1. Revision History
2. Operating Instructions

*************************************************************************
1. Revision History 
*************************************************************************
Date		Version	Revision

05/19/14	1.0	Initial Xilinx release.

04/20/15	1.1	-Added support for all Virtex and Kintex UltraScale parts
			-Removed specs for VREFP and VREFN
			-Fixed error referring to HR bank for "VCCO Bank 65" recommendations with Virtex
			-Updated VCCINT_IO recommendation
			-Updated decoupling capacitor values to be consistent with UG583
			-Fixed reversal of I2C_SCLK and I2C_SDA pin recommendations
			-Added voltage range for Bank 65 recommendations
			-Removed Bank 65 and Bank 0 voltage matching requirement for SPIx1
			-Added pulldown recommendation for VREF when external VREF is not required
			-Added to PERSTN0/1 recommendations
			-Fixed error in additional information for TMS
			-Added AR pointers in additional information for DONE
			-Changed D[31:5] to D[31:4] for Slave and Master Serial recommendations
			-Added note on 100 nF capacitor location for VCCADC and VREFP
			-Added RCAL exception to MGTAVCC, MGTAVTT, and MGTVCCAUX recommendations for unused quads
			-Changed [N or S] to [N, UC, C, LC, or S] for MGT power supply groups
			-Fixed VCCINT voltage recommendation for -1L devices
			-Changed reference for MGT power supply groups to UG575
			-Updated VCCO Bank 65 recommendation for Master SPIx1, SPIx8, Master BPIx8 and Master BPIx16 config modes
			-Updated bitstream length for all parts
			-Updated POR_OVERRIDE recommendation
			-Removed capacitor recommendation for VCCINT_IO/VCCINT merging point
			-Added to additional information for VCCO_65
			-Updated recommendations for VREF
			-Updated pullup recommendation for DONE pin
			-Updated recommendations for INIT_B
			-Added to AD0N to AD15N recommendation
			-Added to I2C_SDA and I2C_SCL recommendation
			-Updated additional information for CFGBVS
			-Updated MGTAVTTRCAL and MGTRREF recommendation
			-Added to recommendation for MIG
			-Removed two rows for items related to memory byte groups and QBC/DBC pins
			-Added KU085 and KU095 devices/packages
			-Added decoupling capacitor numbers for all parts
			-Removed VU160-FLGA2577
			-Removed VU080-FFVC2104
			-Updated recommendations for MGTREFCLK
			-Fixed VCCINT additional information for -1L option
			-Removed note in DONE recommendation and added external pullup
			-Combined positive and negative AD pins
			-Added a pointer to I/O transition/DCI restrictions sections in UG571 for HR/HP bank recommendations
			-Changed instances of "or stronger" to "<=" for pullup resistor values on config pin recommendations

04/19/16	1.2	-For I2C_SCLK/I2C_SDA changed pullup from VCCAUX to VCCO
			-Added note for I2C_SCLK/I2C_SDA regarding being bidirectional
			-Added requirement for a resistor on DCI VRP pin
			-Added pointer to RSA Authentication table in UG570
			-Updated CSI_ADV_B, DOUT_CSO_B, D[31:00], A[28:00], FOE_B, FWE_FCS2_B, RS[1:0] to account for PUDC_B setting during configuration
			-Updated configuration frequencies options to allow the maximum frequency
			-Updated recommendation for VCCO of unused banks to align with the recommendation in UG583
			-Updated recommendation for PERSTN[1:0] as per PG156
			-Added recommendation for a pull-up on TDI in the case that it is connected to a buffer
			-Added a note for unavailability of I/Os for bitslice 0/6 during calibration
			-Added support for KU025 and KU095 in FFVA1156 and for KU035 and KU040 in SFVA784
			-Updated bitstream lengths to match UG570

02/09/17	1.3	-Added a note to MGTREFCLK on RXRECCLK forwarding
			-Added a pointer to "Configuring Multiple FPGAs" chapter of UG570 for DONE pin recommendations
			-Updated device migration info to include UltraScale+ devices
			-Added ruggedized packages (RB, RF, RL) for Kintex UltraScale XQ devices

12/07/17	1.4	-Changed title from "UltraScale Architecture" to "Kintex UltraScale and Virtex UltraScale"
			-Added Item "MGT Mapping"
			-Added note on I/O connections for devices with multiple SLRs

06/04/18	1.5	- Updated recommendations for MGTREFCLK, MGTRX, and MGTAVTTRCAL to match UG576/UG578
			- Added note to DONE about pullup resistance for devices with multiple SLRs

04/02/20	1.6	- Updated power rail decoupling capacitor recommendations according to UG583 udpates

12/17/20	1.7	- Fixed macro issue when selecting package.

*************************************************************************
2. Operating Instructions 
*************************************************************************

!	Macros must be enabled for full functionality.
1.	This spreadsheet is intended to provide a list of what has been checked (and what has not been checked) during a customer schematic review. It is not intended to be a comprehensive checklist.
	
2.	The Project Info page gives an overview of the schematic that is being reviewed, and the person(s) performing the review. It also contains the Purpose and Disclaimer paragraphs.
	
3.	The Checklist pages contain some of the more common items that should be checked. In some cases, these items might not apply to a specific schematic review, and can be deleted. In other cases, there might be additional items that need to be checked. In that case, the user can add a line to the end of the worksheet.
	
4.	In several cells, there are Xilinx recommendations containing question marks (e.g., ? of ?? mf cap ). The question marks are intended to remind the user to replace the '?' with the appropriate value. In this example, the number of caps and the value of those caps need to be recorded.
	
5.	The Checklist pages are intended to collect information for a single FPGA and its supporting device (such as a configuration PROM). At the top of the Checklist page, the device part number and reference designator need to be recorded. If there are multiple devices, a workbook should be created for each device.
	
6.	"Each cell in the Status column has a pull-down menu with the color-coded selections OK, CHECK, and PROBLEM. The Status column allows the customer to quickly see the results of the schematic review.
� OK: The item receives reviewer approval.
� CHECK: The reviewer does not have sufficient information to determine if the item is OK or poses a PROBLEM. The designer must research the item and provide additional information.
� PROBLEM: There is an issue with the item. PROBLEM flags the item for the designer, who needs to research the issue and find a solution.
� Not Checked: The item has not been checked and might require additional attention.
� N/A: The item is not applicable to this device or design."
	
7.	The Actual Implementation column can be used to provide additional clarification. This information is especially important if the item is tagged with CHECK or PROBLEM.
